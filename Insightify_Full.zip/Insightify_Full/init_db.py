# db.py
import os
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base, sessionmaker, relationship
from sqlalchemy.sql import func

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///insightify.db")
Base = declarative_base()

class Upload(Base):
    __tablename__ = "uploads"
    id = Column(Integer, primary_key=True)
    filename = Column(String(255))
    uploaded_at = Column(DateTime(timezone=True), server_default=func.now())
    analyses = relationship("AnalysisResult", back_populates="upload")

class AnalysisResult(Base):
    __tablename__ = "analysis_results"
    id = Column(Integer, primary_key=True)
    upload_id = Column(Integer, ForeignKey("uploads.id"))
    review_column = Column(String(200))
    positive = Column(Integer)
    neutral = Column(Integer)
    negative = Column(Integer)
    total = Column(Integer)
    keywords = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    upload = relationship("Upload", back_populates="analyses")

def init_db():
    engine = create_engine(DATABASE_URL, future=True)
    Base.metadata.create_all(engine)
    return engine

def get_session():
    engine = create_engine(DATABASE_URL, future=True)
    Session = sessionmaker(bind=engine)
    return Session()
