# Insightify_Full - Local AI Review Analyzer

## Overview
Insightify_Full is a Flask web app that analyzes textual reviews using either VADER (fast) or a local BERT model (via FastAPI). It supports CSV/Excel/JSON uploads, auto-detects the review column, performs sentiment analysis, extracts keywords, shows plots and saves summary results to a database.

## Quick start (Conda)
1. Create env and install:
```bash
conda create -n Insightify_Full python=3.10 -y
conda activate Insightify_Full
pip install -r requirements.5
