import os
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
from utils import load_file, auto_detect_review_column
from analyzer import Analyzer
from recommender import Recommender
from db import init_db, get_session, Upload, AnalysisResult
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv()

UPLOAD_FOLDER = "uploads"
ALLOWED_EXT = {".csv", ".xlsx", ".xls", ".json"}

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.environ.get("FLASK_SECRET", "insightify-secret")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

USE_LOCAL_MODEL = os.environ.get("USE_LOCAL_MODEL", "0") == "1"
LOCAL_MODEL_BATCH_URL = os.environ.get("LOCAL_MODEL_URL_BATCH", "http://127.0.0.1:8001/predict_batch")

# Initialize DB
engine = init_db()

@app.route("/", methods=["GET"])
def dashboard():
    return render_template("dashboard.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    uploaded_file = request.files.get("file")
    if not uploaded_file or uploaded_file.filename == "":
        flash("Please upload a CSV/Excel/JSON file.", "danger")
        return redirect(url_for("dashboard"))

    filename = secure_filename(uploaded_file.filename)
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXT:
        flash("Unsupported file type. Use CSV / Excel / JSON.", "danger")
        return redirect(url_for("dashboard"))

    save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    uploaded_file.save(save_path)

    # Load data
    try:
        df = load_file(save_path)
    except Exception as e:
        flash(f"Error loading file: {e}", "danger")
        return redirect(url_for("dashboard"))

    # Detect review column
    try:
        review_col = auto_detect_review_column(df)
    except Exception as e:
        flash(f"Could not detect text column: {e}", "danger")
        return redirect(url_for("dashboard"))

    analyzer = Analyzer(local_model_url=LOCAL_MODEL_BATCH_URL if USE_LOCAL_MODEL else None)

    # Analyze sentiment
    if USE_LOCAL_MODEL:
        result_df = analyzer.analyze_with_local_api(df, review_col, LOCAL_MODEL_BATCH_URL)
    else:
        result_df = analyzer.analyze_vader(df, review_col)

    summary = analyzer.summarize_sentiments(result_df["sentiment"])
    keywords = analyzer.extract_keywords(result_df["clean_text"], top_n=20)

    # Recommendations
    recommender = Recommender()
    recs = recommender.advanced_recommendations(result_df)
    similar = recommender.recommend_similar_reviews(result_df, text_col="clean_text", top_n=3)

    # Save upload & analysis results to DB
    session = get_session()
    upload = Upload(filename=filename)
    session.add(upload)
    session.commit()

    ar = AnalysisResult(
        upload_id=upload.id,
        review_column=review_col,
        positive=summary["positive"],
        neutral=summary["neutral"],
        negative=summary["negative"],
        total=summary["total"],
        keywords=json.dumps(keywords)
    )
    session.add(ar)
    session.commit()

    # Prepare visualization data
    pie_data = {
        "labels": ["Positive", "Neutral", "Negative"],
        "values": [summary["positive"], summary["neutral"], summary["negative"]]
    }
    kw_words = [w for w, c in keywords]
    kw_counts = [c for w, c in keywords]

    # Show only first 5 rows
    num_rows = 5
    table_html = result_df.head(num_rows).to_html(classes="table table-striped table-sm", index=False)

    return render_template(
        "results.html",
        filename=filename,
        review_col=review_col,
        summary=summary,
        keywords=keywords,
        recommendations=recs,
        similar=similar,
        table_html=table_html,
        pie_data=json.dumps(pie_data),
        kw_words=json.dumps(kw_words),
        kw_counts=json.dumps(kw_counts),
        num_rows=num_rows
    )

if __name__ == "__main__":
    app.run(debug=True)