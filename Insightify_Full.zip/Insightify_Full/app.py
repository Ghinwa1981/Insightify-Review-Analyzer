import os
import json
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
from utils import load_file, auto_detect_review_column
from analyzer import Analyzer
from recommender import Recommender
from db import init_db, Upload, AnalysisResult, get_db_session
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

UPLOAD_FOLDER = "uploads"
ALLOWED_EXT = {".csv", ".xlsx", ".xls", ".json"}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB limit

# Example uploaded file path (from your session). We'll pass it to template if needed.
UPLOADED_EXAMPLE_PATH = "/mnt/data/4_5850204842559019972 (2).rar"

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.environ.get("FLASK_SECRET", "insightify-secret")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_FILE_SIZE
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

USE_LOCAL_MODEL = os.environ.get("USE_LOCAL_MODEL", "0") == "1"
LOCAL_MODEL_BATCH_URL = os.environ.get("LOCAL_MODEL_URL_BATCH", "http://127.0.0.1:8001/predict_batch")

@app.route("/", methods=["GET"])
def dashboard():
    return render_template("dashboard.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    uploaded_file = request.files.get("file")
    if not uploaded_file or uploaded_file.filename == "":
        flash("Please upload a CSV/Excel/JSON file.", "danger")
        return redirect(url_for("dashboard"))

    filename = secure_filename(uploaded_file.filename)
    if not filename:
        flash("Invalid filename.", "danger")
        return redirect(url_for("dashboard"))
    
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXT:
        flash("Unsupported file type. Use CSV / Excel / JSON.", "danger")
        return redirect(url_for("dashboard"))

    save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    try:
        uploaded_file.save(save_path)
        # Check file size
        file_size = os.path.getsize(save_path)
        if file_size > MAX_FILE_SIZE:
            os.remove(save_path)
            flash(f"File too large. Maximum size is {MAX_FILE_SIZE / (1024*1024):.1f}MB.", "danger")
            return redirect(url_for("dashboard"))
    except Exception as e:
        flash(f"Error saving file: {e}", "danger")
        return redirect(url_for("dashboard"))

    # Load data
    try:
        df = load_file(save_path)
        if df.empty:
            flash("The uploaded file is empty.", "danger")
            return redirect(url_for("dashboard"))
        if len(df.columns) == 0:
            flash("The uploaded file has no columns.", "danger")
            return redirect(url_for("dashboard"))
    except Exception as e:
        flash(f"Error loading file: {e}", "danger")
        if os.path.exists(save_path):
            try:
                os.remove(save_path)
            except:
                pass
        return redirect(url_for("dashboard"))

    # Detect review column
    try:
        review_col = auto_detect_review_column(df)
    except Exception as e:
        flash(f"Could not detect text column: {e}", "danger")
        return redirect(url_for("dashboard"))

    analyzer = Analyzer(local_model_url=LOCAL_MODEL_BATCH_URL if USE_LOCAL_MODEL else None)

    # Analyze sentiment
    try:
        if USE_LOCAL_MODEL:
            result_df = analyzer.analyze_with_local_api(df, review_col, LOCAL_MODEL_BATCH_URL)
        else:
            result_df = analyzer.analyze_vader(df, review_col)
    except Exception as e:
        flash(f"Error during analysis: {e}", "danger")
        return redirect(url_for("dashboard"))

    # Prepare summary and keywords
    summary = analyzer.summarize_sentiments(result_df["sentiment"])
    keywords = analyzer.extract_keywords(result_df["clean_text"], top_n=20)

    # Recommendations
    recommender = Recommender()
    recs = recommender.advanced_recommendations(result_df)
    similar = recommender.recommend_similar_reviews(result_df, text_col="clean_text", top_n=3)

    # Save upload & analysis results to DB
    try:
        with get_db_session() as session:
            upload = Upload(filename=filename)
            session.add(upload)
            session.flush()  # Get the ID without committing yet
            
            ar = AnalysisResult(
                upload_id=upload.id,
                review_column=review_col,
                positive=summary["positive"],
                neutral=summary["neutral"],
                negative=summary["negative"],
                total=summary["total"],
                keywords=json.dumps(keywords)
            )
            session.add(ar)
            # Context manager will commit automatically
    except Exception as e:
        # DB errors shouldn't stop the user from seeing results
        flash(f"Error saving to database: {e}", "warning")

    # Prepare visualization data for templates
    pie_data = {
        "labels": ["Positive", "Neutral", "Negative"],
        "values": [summary["positive"], summary["neutral"], summary["negative"]]
    }
    kw_words = [w for w, c in keywords]
    kw_counts = [c for w, c in keywords]

    # --- NEW: Prepare pattern categories & sentiment counts per category (for diverging chart)
    # Use top 5 keywords as categories (fallback to manual categories if not enough)
    try:
        top_n = 5
        if len(kw_words) >= top_n:
            pattern_categories = kw_words[:top_n]
        else:
            # fallback categories — you can customize
            pattern_categories = kw_words + ["delivery", "price", "quality", "service", "value"]
            pattern_categories = pattern_categories[:top_n]

        # For each category keyword, count positive/neutral/negative mentions
        pattern_pos = []
        pattern_neu = []
        pattern_neg = []
        # lowercased clean_text series for faster search
        clean_texts = result_df["clean_text"].fillna("").astype(str)

        for cat in pattern_categories:
            cat_l = str(cat).lower()
            pos_count = int(((result_df["sentiment"] == "POSITIVE") & clean_texts.str.contains(r"\b" + cat_l + r"\b", regex=True)).sum())
            neu_count = int(((result_df["sentiment"] == "NEUTRAL") & clean_texts.str.contains(r"\b" + cat_l + r"\b", regex=True)).sum())
            neg_count = int(((result_df["sentiment"] == "NEGATIVE") & clean_texts.str.contains(r"\b" + cat_l + r"\b", regex=True)).sum())

            pattern_pos.append(pos_count)
            pattern_neu.append(neu_count)
            # negative values for diverging chart (left side)
            pattern_neg.append(-neg_count)
    except Exception as e:
        # If anything goes wrong, fallback to sample data so template still renders
        pattern_categories = ["Delivery", "Quality", "Support", "Price", "Others"]
        pattern_pos = [45, 30, 20, 25, 10]
        pattern_neu = [5, 10, 5, 5, 2]
        pattern_neg = [-10, -25, -15, -5, -5]

    # Show only first 5 rows
    num_rows = 5
    table_html = result_df.head(num_rows).to_html(classes="table table-striped table-sm", index=False)

    return render_template(
        "results.html",
        filename=filename,
        review_col=review_col,
        summary=summary,
        keywords=keywords,
        recommendations=recs,
        similar=similar,
        table_html=table_html,
        pie_data=json.dumps(pie_data),
        kw_words=json.dumps(kw_words),
        kw_counts=json.dumps(kw_counts),
        # new pattern vars (JSON strings so template/JS can use them directly)
        pattern_categories=json.dumps(pattern_categories),
        pattern_pos=json.dumps(pattern_pos),
        pattern_neg=json.dumps(pattern_neg),
        pattern_neu=json.dumps(pattern_neu),
        num_rows=num_rows,
        # pass example uploaded path (from your environment) — optional, for download link or debug
        uploaded_example_path=UPLOADED_EXAMPLE_PATH
    )

@app.errorhandler(413)
def request_entity_too_large(error):
    flash("File too large. Maximum size is 50MB.", "danger")
    return redirect(url_for("dashboard"))

@app.errorhandler(500)
def internal_error(error):
    flash("An internal error occurred. Please try again.", "danger")
    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    # Initialize database on startup
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)