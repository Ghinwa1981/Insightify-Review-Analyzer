from collections import Counter

class Recommender:
    def __init__(self):
        pass

    def advanced_recommendations(self, df):
        """
        Generate AI-based actionable recommendations with automatic type classification.
        """
        if "sentiment" not in df.columns:
            return [{"text": "No sentiment column found.", "type": "info"}]

        total = len(df)
        if total == 0:
            return [{"text": "No reviews available to analyze.", "type": "info"}]

        pos = (df["sentiment"] == "POSITIVE").sum()
        neg = (df["sentiment"] == "NEGATIVE").sum()
        neu = (df["sentiment"] == "NEUTRAL").sum()

        neg_pct = neg / total
        pos_pct = pos / total

        recs = []

        # 1️⃣ Sentiment-based recommendations
        if neg_pct > 0.3:
            recs.append({"text": f"High negative rate ({neg_pct*100:.1f}%) — investigate product/service quality immediately.", "type": "urgent"})
        elif neg_pct > 0.1:
            recs.append({"text": f"Moderate negative rate ({neg_pct*100:.1f}%) — consider improvements based on feedback.", "type": "warning"})

        if pos_pct < 0.2:
            recs.append({"text": f"Low positive rate ({pos_pct*100:.1f}%) — run targeted customer satisfaction surveys.", "type": "warning"})

        # 2️⃣ Keyword-based recommendations
        text_col = "clean_text" if "clean_text" in df.columns else None
        if text_col:
            words = " ".join(df[text_col].fillna("").astype(str).tolist()).split()
            c = Counter([w.lower() for w in words if len(w) > 4])
            common = [w for w, _ in c.most_common(10)]
            
            if any(k in common for k in ["price", "expensive"]):
                recs.append({"text": "Many mentions of price — review pricing and value proposition.", "type": "warning"})
            if any(k in common for k in ["quality", "defect", "broken"]):
                recs.append({"text": "Mentions of quality issues — check product/service defects.", "type": "urgent"})

        # 3️⃣ Top negative reviews
        if text_col:
            neg_reviews = df[df["sentiment"] == "NEGATIVE"][text_col].head(3).tolist()
            for r in neg_reviews:
                recs.append({"text": f"Negative review to inspect: {r}", "type": "urgent"})

        # 4️⃣ Default if nothing found
        if not recs:
            recs.append({"text": "No urgent issues detected — continue monitoring and set alerts for spikes in negative feedback.", "type": "info"})

        return recs

    def recommend_similar_reviews(self, df, text_col="clean_text", top_n=3):
        """
        Return first N negative reviews as 'to inspect' examples.
        """
        if text_col not in df.columns:
            return []
        negs = df[df["sentiment"] == "NEGATIVE"]
        return negs[text_col].head(top_n).astype(str).tolist()
