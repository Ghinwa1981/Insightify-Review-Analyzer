# utils.py
import pandas as pd
import os

def load_file(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        return pd.read_csv(path)
    elif ext in [".xlsx", ".xls"]:
        return pd.read_excel(path)
    elif ext == ".json":
        return pd.read_json(path, lines=False)
    else:
        raise ValueError("Unsupported file type")

def auto_detect_review_column(df):
    """
    Try to detect column that likely contains reviews/text.
    Strategy:
    - Common names: reviews.text, review, text, comment, feedback, message
    - Otherwise choose column with highest average word count
    """
    candidates = []
    names = [c.lower() for c in df.columns]
    mapping = dict(zip(names, df.columns))

    common = ["reviews.text", "review", "text", "comment", "feedback", "message", "content"]
    for n in common:
        if n in mapping:
            return mapping[n]

    # otherwise pick column with most string-like content
    best_col = None
    best_avg_words = 0
    for col in df.columns:
        try:
            sample = df[col].dropna().astype(str).head(500)
            if len(sample) == 0:
                continue
            avg_words = sample.apply(lambda x: len(str(x).split())).mean()
            if avg_words > best_avg_words:
                best_avg_words = avg_words
                best_col = col
        except Exception:
            continue

    if best_col is None:
        raise ValueError("Could not detect a text column. Please provide file with readable text column.")
    return best_col
