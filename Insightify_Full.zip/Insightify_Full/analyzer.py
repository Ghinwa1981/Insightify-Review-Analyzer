import re
from collections import Counter
import pandas as pd
import requests
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import nltk
nltk.download("vader_lexicon", quiet=True)

sia = SentimentIntensityAnalyzer()

class Analyzer:
    def __init__(self, local_model_url=None):
        self.local_model_url = local_model_url

    def clean_text(self, text):
        if not isinstance(text, str):
            return ""
        t = text.lower()
        t = re.sub(r"http\S+|www\S+|https\S+", " ", t)
        t = re.sub(r"[^a-z0-9\s]", " ", t)
        t = re.sub(r"\s+", " ", t).strip()
        return t

    def _label_from_score(self, score):
        if score >= 0.2:
            return "POSITIVE"
        elif score <= -0.2:
            return "NEGATIVE"
        else:
            return "NEUTRAL"

    def analyze_vader(self, df, review_col):
        df = df.copy()
        df["clean_text"] = df[review_col].astype(str).apply(self.clean_text)
        df["vader_score"] = df["clean_text"].apply(lambda t: sia.polarity_scores(t)["compound"])
        df["sentiment"] = df["vader_score"].apply(self._label_from_score)
        return df

    def analyze_with_local_api(self, df, review_col, api_url, batch_size=64, timeout=20):
        df = df.copy()
        df["clean_text"] = df[review_col].astype(str).apply(self.clean_text)
        texts = df["clean_text"].tolist()
        labels = []
        scores = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            try:
                r = requests.post(api_url, json={"texts": batch}, timeout=timeout)
                r.raise_for_status()
                data = r.json()
                res = data.get("results", [])
                for item in res:
                    labels.append(item.get("label", "NEUTRAL"))
                    scores.append(item.get("score", 0.0))
            except Exception:
                for t in batch:
                    sc = sia.polarity_scores(t)["compound"]
                    labels.append(self._label_from_score(sc))
                    scores.append(sc)

        df["model_score"] = scores
        df["sentiment"] = [lbl.upper() for lbl in labels]
        return df

    def extract_keywords(self, series, top_n=20):
        tokens = []
        for t in series:
            if not isinstance(t, str):
                continue
            tokens.extend([w for w in t.split() if len(w) > 3])
        counter = Counter(tokens)
        return counter.most_common(top_n)

    def summarize_sentiments(self, series):
        pos = int((series == "POSITIVE").sum())
        neu = int((series == "NEUTRAL").sum())
        neg = int((series == "NEGATIVE").sum())
        total = pos + neu + neg if (pos+neu+neg)>0 else len(series)
        return {"positive": pos, "neutral": neu, "negative": neg, "total": total}
