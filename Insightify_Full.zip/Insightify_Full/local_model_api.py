# local_model_api.py
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline
import torch

app = FastAPI(title="Insightify Local Model API")

MODEL_NAME = "distilbert-base-uncased-finetuned-sst-2-english"

# load tokenizer and model once
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME)

# device selection for pipeline
device = 0 if torch.cuda.is_available() else -1
sentiment_pipe = pipeline("sentiment-analysis", model=model, tokenizer=tokenizer, device=device)

class TextItem(BaseModel):
    text: str

class BatchRequest(BaseModel):
    texts: List[str]

@app.post("/predict")
def predict(item: TextItem):
    res = sentiment_pipe(item.text, truncation=True, max_length=512)
    return {"label": res[0]["label"], "score": float(res[0]["score"])}

@app.post("/predict_batch")
def predict_batch(req: BatchRequest):
    results = sentiment_pipe(req.texts, truncation=True, max_length=512, batch_size=16)
    out = [{"label": r["label"], "score": float(r["score"])} for r in results]
    return {"results": out}
